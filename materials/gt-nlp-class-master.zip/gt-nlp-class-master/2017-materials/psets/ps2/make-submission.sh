tar cvzf pset2-submission.tgz `cat manifest.txt`
