Problem Set 1
========

Georgia Tech CS 4650 & 7650, Spring 2017

Please clone or download this repository to do the problem set. 

Instructions are in [pset1.ipynb](pset1.ipynb). 

You will also need to unzip [reddit-data.tgz](reddit-data.tgz).

To submit the problem set, run ```make-submission.sh```, and upload the resulting file to T-Square.

The problem set was written and tested in Python 2.7.12, iPython 5.0.0, Jupyter notebook server 4.2.2.

Teachers, you are welcome to re-use any part of this problem set. Please let me know if you do.
