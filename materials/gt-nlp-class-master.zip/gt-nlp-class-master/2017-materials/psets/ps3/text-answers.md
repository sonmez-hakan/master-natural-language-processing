# 1.8

As you can see from the cells here, the Japanese tagger suffered more of a decrease in accuracy when moving to the test data. Why might that be?


# 2.3

Explain why you think suffix features are so helpful in Japanese. You may want to look at the raw data, and consult some resources that you can find from Google. (No prior Japanese knowledge is assumed!)

