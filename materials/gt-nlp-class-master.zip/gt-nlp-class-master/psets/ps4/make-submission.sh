tar cvzf pset4-submission.tgz `cat manifest.txt`
