Answer to Deliverable 4.6:
