Problem Set 3: Dependency Parsing
==============

- The prompts are in the [notebook](pset3.ipynb)
- English bakeoff: https://www.kaggle.com/t/af7c23c6d2bd42a2b6929a19f0768a5d
- Norwegian bakeoff: https://www.kaggle.com/t/6269257565b04cd39ee2ab8735d443fe
