tar cvzf pset3-submission.tgz `cat manifest.txt`
